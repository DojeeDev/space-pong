# godot-time-tracker
A lightweight, unintrusive time-tracker for your Godot project.

- Keep track of total time spent with your project open in the editor
- Keep track of your current session
